
======= 说明：

当前目录：/src/main/resources/views/themes/default/modules/

是【default】主题的模块视图目录，该目录下的文件，会自动覆盖：

/src/main/resources/views/modules/ 下的默认视图文件。

======= 举例：

拷贝文件：/src/main/resources/views/modules/sys/sysLogin.html

复制到：/src/main/resources/views/themes/default/modules/sys/sysLogin.html

这样写，默认的视图文件就会被替换为你自定义的视图文件，从而实现简单的自定义视图。

======= 更多资料：

http://jeesite.com/docs/custom-views/

