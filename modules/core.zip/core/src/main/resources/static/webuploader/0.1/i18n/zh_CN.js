(function($) {
	
})(jQuery);
